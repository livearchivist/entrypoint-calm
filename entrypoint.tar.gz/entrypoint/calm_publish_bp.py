"""
calm_publish_bp.py: automation to publish blueprints into
the Marketplace Manager on NX-on-GCP / Test Drive.

Author: michael@nutanix.com
Date:   2020-03-05
"""

import sys
import os
import json

sys.path.append(os.path.join(os.getcwd(), "nutest_gcp.egg"))

from framework.lib.nulog import INFO, ERROR
from helpers.rest import RequestResponse
from helpers.calm import (file_to_dict, uuid_via_v3_post,
                          upload_bp_via_v3_post,
                          get_subnet_info)

def main():

  # Get and log the config from the Env variable
  config = json.loads(os.environ["CUSTOM_SCRIPT_CONFIG"])
  INFO(config)

  # Get PC info from the config dict
  pc_info = config.get("tdaas_pc")
  pc_external_ip = pc_info.get("ips")[0][0]
  pc_internal_ip = pc_info.get("ips")[0][1]
  pc_password = pc_info.get("prism_password")

  try:

    # Read in the spec files and conver to dicts
    bp_pub_spec = file_to_dict("specs/calm_bp_publish.spec")
    INFO(f"bp_spec: {bp_spec}")

    # Get user info
    user_spec = body_via_v3_get(pc_external_ip, "users",
                                pc_password, "me").json

    # Loop through the blueprints to upload
    for bp in bp_pub_spec["entities"]:

      # Create our payload and get bp uuid
      payload = {
        "filter": f"name==bp['bp_name']"
      }
      bp_info = body_via_v3_post(pc_external_ip, "blueprints",
                                 pc_password, payload).json
      bp_uuid = bp_info["entities"][0]["metadata"]["uuid"]

      # Get bp spec with uuid
      bp_spec = body_via_v3_get(pc_external_ip, "blueprints",
                                pc_password,
                                f"{bp_uuid}/export_json").json

      # Modify our spec HERE
      del bp_spec["status"]

      # Upload our blueprint
      resp = upload_bp_via_v3_post(pc_external_ip, pc_password,
                                   payload, bp["bp_file"])

      # Log appropriately based on response
      if (resp.code == 200 or resp.code == 202):
        INFO(f"{bp['bp_name']} blueprint created successfully.")
      else:
        raise Exception(f"{bp['bp_name']} blueprint create" +
                        f" failed with:\n" +
                        f"Error Code: {resp.code}\n" +
                        f"Error Message: {resp.message}")

  except Exception as ex:
    INFO(ex)

if __name__ == '__main__':
  main()

